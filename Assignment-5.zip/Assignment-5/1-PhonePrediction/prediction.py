import pandas
from sklearn.tree import DecisionTreeClassifier

moviedata=pandas.read_csv('phone.csv')
#print(moviedata)

#training data
features=moviedata.drop(columns=['mobile'])
labels=moviedata['mobile']

#build a model
model=DecisionTreeClassifier()
model.fit(features,labels)

#test data and predict
result=model.predict([[65, 2, 75000], [27, 1, 55000], [45, 2, 5000]])
print(result)

'''
output -> ['samsung' 'apple' 'realme']
that means a person who is female, age 65 and income is 75000 will prefer Samsung
a person who is male of age 27 and income is 55000 will prefer Apple
a person who is female of age 45 and income is 5000 will prefer Realme
1 for male & 2 for female
'''